package com.example.sumufinalproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class CartFragemnt extends Fragment {
    View view;
    Button btn,plus,minas,plus1,minas1;
    TextView itemview,priceview,itemview1,priceview1,subtotal,tax,total;
    String dataPass = "";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view  =  inflater.inflate(R.layout.fragment_cart_fragemnt, container, false);
        btn = view.findViewById(R.id.GoToPaymentOption);
        plus = view.findViewById(R.id.ItemPlusId);
        minas=view.findViewById(R.id.ItemMinasId);
        itemview = view.findViewById(R.id.ItemveiwId);
        priceview = view.findViewById(R.id.ItemPriceId);
        plus1 = view.findViewById(R.id.ItemPlusId1);
        minas1=view.findViewById(R.id.ItemMinasId1);
        itemview1 = view.findViewById(R.id.ItemveiwId1);
        priceview1 = view.findViewById(R.id.ItemPriceId1);
        subtotal = view.findViewById(R.id.subtotal);
        tax = view.findViewById(R.id.TaxView);
        total=view.findViewById(R.id.totalID);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataPass = total.getText().toString();
                Fragment frag1 = new payment1Fragment();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",dataPass);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float count,price,subtotaltext,taxtext,totaltext;
                count = Float.parseFloat(itemview.getText().toString())+1;
                price = Float.parseFloat(priceview.getText().toString())+14000;
                subtotaltext = Float.parseFloat(priceview.getText().toString())+Float.parseFloat(priceview1.getText().toString())+14000;
                taxtext=subtotaltext*5/100;
                totaltext=subtotaltext+taxtext;
                itemview.setText(count.toString());
                priceview.setText(price.toString());
                subtotal.setText(subtotaltext.toString()+ " Taka");
                tax.setText(taxtext.toString()+ " Taka");
                total.setText(totaltext.toString()+ " Taka");
            }
        });
        minas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float count,price,subtotaltext,taxtext,totaltext;
                count = Float.parseFloat(itemview.getText().toString())-1;
                price = Float.parseFloat(priceview.getText().toString())-14000;
                subtotaltext = Float.parseFloat(priceview.getText().toString())+Float.parseFloat(priceview1.getText().toString())-14000;
                taxtext=subtotaltext*5/100;
                totaltext=subtotaltext+taxtext;
                itemview.setText(count.toString());
                priceview.setText(price.toString());
                subtotal.setText(subtotaltext.toString()+ " Taka");
                tax.setText(taxtext.toString()+ " Taka");
                total.setText(totaltext.toString()+ " Taka");
            }
        });
        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float count,price,subtotaltext,taxtext,totaltext;
                count = Float.parseFloat(itemview1.getText().toString())+1;
                price = Float.parseFloat(priceview1.getText().toString())+2800;
                subtotaltext = Float.parseFloat(priceview.getText().toString())+Float.parseFloat(priceview1.getText().toString())+2800;
                taxtext=subtotaltext*5/100;
                totaltext=subtotaltext+taxtext;
                itemview1.setText(count.toString());
                priceview1.setText(price.toString());
                subtotal.setText(subtotaltext.toString()+ " Taka");
                tax.setText(taxtext.toString()+ " Taka");
                total.setText(totaltext.toString()+ " Taka");

            }
        });
        minas1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float count,price,subtotaltext,taxtext,totaltext;
                count = Float.parseFloat(itemview1.getText().toString())-1;
                price = Float.parseFloat(priceview1.getText().toString())-2800;
                subtotaltext = Float.parseFloat(priceview.getText().toString())+Float.parseFloat(priceview1.getText().toString())-2800;
                taxtext=subtotaltext*5/100;
                totaltext=subtotaltext+taxtext;
                itemview1.setText(count.toString());
                priceview1.setText(price.toString());
                subtotal.setText(subtotaltext.toString()+ " Taka");
                tax.setText(taxtext.toString()+ " Taka");
                total.setText(totaltext.toString()+ " Taka");
            }
        });
        return view;
    }

}