package com.example.sumufinalproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class payment3 extends Fragment {
    View view;
    Button btn,button;
    TextView show;
    EditText name,number;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_payment3, container, false);
        show = view.findViewById(R.id.showpayment);
        name = view.findViewById(R.id.cashholdername3);
        number = view.findViewById(R.id.cardnumber3);
        button = view.findViewById(R.id.buttonid3);
        Bundle bundle = this.getArguments();
        String Ammount = bundle.getString("Ammount");
        show.setText(Ammount);
        btn = view.findViewById(R.id.GotoStatusPagefromcreadit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name1 = name.getText().toString();
                String number1 = number.getText().toString();
                String paidby = button.getText().toString();
                Fragment frag1 = new statusFragment();
                Bundle bundle1 = new Bundle();
                bundle1.putString("Ammount",Ammount);
                bundle1.putString("Number",number1);
                bundle1.putString("Name",name1);
                bundle1.putString("PaidBY",paidby);
                frag1.setArguments(bundle1);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });
        return view;
    }
}