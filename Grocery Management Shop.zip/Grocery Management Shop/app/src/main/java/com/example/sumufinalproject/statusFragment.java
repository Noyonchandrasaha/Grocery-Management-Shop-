package com.example.sumufinalproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class statusFragment extends Fragment {

    View view;
    Button t1;
    TextView ammount,name,number,paidBy;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_status, container, false);
        ammount = view.findViewById(R.id.ammountId);
        name = view.findViewById(R.id.nameid);
        number = view.findViewById(R.id.cardnumberid);
        paidBy = view.findViewById(R.id.paidby);
        Bundle bundle = this.getArguments();
        ammount.setText("Total Paid  "+bundle.getString("Ammount"));
        number.setText("Number "+bundle.getString("Number"));
        name.setText("Name "+bundle.getString("Name"));
        paidBy.setText("Paid By: "+bundle.getString("PaidBY"));
        t1 = view.findViewById(R.id.gotocartId);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new CartFragemnt();
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });
        return view;
    }
}