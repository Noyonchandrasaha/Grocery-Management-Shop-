package com.example.sumufinalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView text1;
    Button btn;
    ImageView pagelogo,pagelogo2;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = findViewById(R.id.text2id);
        btn = findViewById(R.id.buttonid);
        pagelogo = findViewById(R.id.pagelogo);
        pagelogo2 = findViewById(R.id.pagelogo2);
    }

    public void goCheckOutPage(View view) {
        Fragment frag1 = new CartFragemnt();
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        btn.setVisibility(View.GONE);
        text1.setVisibility(View.GONE);
        pagelogo.setVisibility(View.GONE);
        pagelogo2.setVisibility(View.GONE);
    }
}