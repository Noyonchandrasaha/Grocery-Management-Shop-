package com.example.sumufinalproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class payment1Fragment extends Fragment {
    View view;

    Button btn1,btn2,btn3,btn4,btn5,prevbtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_payment1, container, false);
        Bundle bundle = this.getArguments();
        String data = bundle.getString("Ammount");
        btn1 = view.findViewById(R.id.GoTodebitcard);
        btn2 = view.findViewById(R.id.GoTocreditCard);
        btn3 = view.findViewById(R.id.GoTobkash);
        btn4 = view.findViewById(R.id.GoTorocket);
        btn5 = view.findViewById(R.id.GoTonagad);
        prevbtn = view.findViewById(R.id.gotocartId);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new payment2Fragment();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag2 = new payment3();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag2.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag2).commit();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new payment4();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new payment5();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new payment6();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout, frag1).commit();
            }
        });
        prevbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment frag1 = new CartFragemnt();
                Bundle bundle = new Bundle();
                bundle.putString("Ammount",data);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });

        return view;
    }
}